# msu-museums-website
A front-end website built for the purposes of pulling data from a Kora digital repository and displaying it on a web page. 
